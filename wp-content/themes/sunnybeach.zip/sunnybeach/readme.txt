Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/sunnybeach/
Buy theme: http://smthemes.com/buy/sunnybeach/
Support Forums: http://smthemes.com/support/forum/sunnybeach-free-wordpress-theme/